<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Edit</title>
	</head>

	<style>
		.button {
		  border: none;
		  color: white;
		  padding: 11px 27px;
		  text-align: center;
		  text-decoration: none;
		  display: inline-block;
		  font-size: 15px;
		  margin: 40px 2px;
		  transition-duration: 0.4s;
		  cursor: pointer;
		}

		.button1 {
		  background-color: red; 
		  color: white; 
		}

		.button1:hover {
		  background-color: green;
		  color: white;
		}

	</style>
	<body>
		<h1>Edit Data User</h1>
		<?php
			include('koneksi.php');

			$kode_user = $_GET['kode_user'];

			$query = mysqli_query($konek, "SELECT * FROM user WHERE kode_user=$kode_user");
			$data = mysqli_fetch_array($query);
		?>

		<form action="aksi_edit.php" method="POST">
			<input type="hidden" name="kode_user" value="<?php echo $data['kode_user'];?>">
			Nama<br>
			<input type="text" name="nama" value="<?php echo $data['nama'];?>"><br>
			Email<br>
			<input type="text" name="email" value="<?php echo $data['email'];?>"><br>
			Telepon<br>
			<input type="text" name="telp" value="<?php echo $data['telp'];?>"><br>
			Password<br>
			<input type="Password" name="password" value="<?php echo $data['password'];?>"><br>
			Peran<br>
			<input type="text" name="peran" value="<?php echo $data['peran'];?>"><br>
			<input type="submit" value="Kirim">
		</form>

		<a href="berhasil_login.php"><button class="button button1" onclick="logout.php">Home</button></a>
	</body>
</html>

