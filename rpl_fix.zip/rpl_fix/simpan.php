<?php
	include('koneksi.php');
	
	$nama = $_POST['nama'];
	$email = $_POST['email'];
	$telp = $_POST['telp'];
	$password = $_POST['password'];
	$peran = $_POST['peran'];

	$query = "INSERT INTO user(nama, email, telp, password, peran) values('$nama', '$email', '$telp', '$password', '$peran')";
	mysqli_query($konek, $query);
?>