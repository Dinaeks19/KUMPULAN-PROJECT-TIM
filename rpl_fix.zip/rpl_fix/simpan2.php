<?php
	include('koneksi.php');
	
	$nama = $_POST['nama'];
	$alamat = $_POST['alamat'];
	$telp = $_POST['telp'];
	$kode_user = $_POST['kode_user'];
	

	$query = "INSERT INTO pelanggan(nama, alamat, telp, kode_user) values('$nama', '$alamat', '$telp', '$kode_user')";
	mysqli_query($konek, $query);
?>