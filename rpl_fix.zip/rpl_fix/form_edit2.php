<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Edit</title>
	</head>

	<style>
		.button {
		  border: none;
		  color: white;
		  padding: 11px 27px;
		  text-align: center;
		  text-decoration: none;
		  display: inline-block;
		  font-size: 15px;
		  margin: 40px 2px;
		  transition-duration: 0.4s;
		  cursor: pointer;
		}

		.button1 {
		  background-color: red; 
		  color: white; 
		}

		.button1:hover {
		  background-color: green;
		  color: white;
		}

	</style>
	<body>
		<h1>Edit Data Pelanggan</h1>
		<?php
			include('koneksi.php');

			$kode_pelanggan = $_GET['kode_pelanggan'];

			$query = mysqli_query($konek, "SELECT * FROM pelanggan WHERE kode_pelanggan=$kode_pelanggan");
			$data = mysqli_fetch_array($query);
		?>

		<form action="aksi_edit2.php" method="POST">
			<input type="hidden" name="kode_pelanggan" value="<?php echo $data['kode_pelanggan'];?>">
			Nama<br>
			<input type="text" name="nama" value="<?php echo $data['nama'];?>"><br>
			Alamat<br>
			<input type="text" name="alamat" value="<?php echo $data['alamat'];?>"><br>
			Telepon<br>
			<input type="text" name="telp" value="<?php echo $data['telp'];?>"><br>
			Kode User<br>
			<input type="number" name="kode_user" value="<?php echo $data['kode_user'];?>"><br>
			<input type="submit" value="Kirim">
		</form>

		<a href="berhasil_login.php"><button class="button button1" onclick="logout.php">Home</button></a>
	</body>
</html>

