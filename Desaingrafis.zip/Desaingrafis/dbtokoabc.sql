-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 09 Okt 2022 pada 12.41
-- Versi server: 10.4.24-MariaDB
-- Versi PHP: 7.4.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbtokoabc`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `cart`
--

CREATE TABLE `cart` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` int(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `quantity` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `cart`
--

INSERT INTO `cart` (`id`, `name`, `price`, `image`, `quantity`) VALUES
(23, 'Aglonema Khocin', 35000, 'aglonemaKhocin.jpg', 1),
(24, 'Aglonema Red ', 75000, 'aglonemaRedAnjamaniDewasa.jpg', 1),
(25, 'Aglonema Ayunindi', 35000, 'aglonemaAyunindi.jpg', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `order`
--

CREATE TABLE `order` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `number` int(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `method` varchar(255) NOT NULL,
  `flat` varchar(255) NOT NULL,
  `street` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `country` varchar(255) NOT NULL,
  `pin_code` int(255) NOT NULL,
  `total_products` int(255) NOT NULL,
  `total_price` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `order`
--

INSERT INTO `order` (`id`, `name`, `number`, `email`, `method`, `flat`, `street`, `city`, `state`, `country`, `pin_code`, `total_products`, `total_price`) VALUES
(1, 'Dina', 1, 'dinaa@gmail.com', 'cash on delivery', 'aa', 'Kenanga', 'Surabaya', 'Indonesia', 'Indonesia', 1111, 0, 3),
(2, 'Etika', 2, 'Etika@gmail.com', 'cash on delivery', 'aa', 'Kenanga', 'Surabaya', 'Indonesia', 'Indonesia', 2222, 0, 2),
(5, 'Dina Etikasari', 2147483647, 'DinaE123@gmail.com', 'cash on delivery', 'Kenanga', 'kenanga01', 'Surabaya', 'indonesia', 'Indonesia', 12345, 0, 235),
(6, 'shine', -2, 'dina@gmail.com', 'cash on delivery', 'e', 'c', 'Kebumen', 'c', 'fww', 1111, 0, 235),
(7, 'DINA ETIKASARI', 11111111, 'dina@gmail.com', 'credit cart', 'Kebumen', 'Kebumen', 'Kebumen', 'Pahlawan', 'Indonesia', 12345, 0, 235),
(8, 'javgwj', 32, 'shine@gmail.com', 'cash on delivery', 'OUQHE', 'FW', 'EQFEW', 'QF', 'WEFWE', 0, 0, 235);

-- --------------------------------------------------------

--
-- Struktur dari tabel `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` int(255) NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `products`
--

INSERT INTO `products` (`id`, `name`, `price`, `image`) VALUES
(1, 'Banner Sponsor', 43000, 'Banner Sponsor.jepg'),
(2, 'Poster cover buku 1', 20000, 'Poster cover buku 1.jpeg'),
(3, 'Poster cover buku 2', 75000, 'Poster cover buku 2.png'),
(4, 'Poster Graduation', 20000, 'Poster Graduation.jpeg'),
(5, 'Poster Promosi', 22000, 'Poster Promosi.jpeg'),
(6, 'Poster Ulang Tahun Anak\r\n', 22000, 'Poster Ulang Tahun Anak.png'),
(7, 'Poster Ulang Tahun Sweet Seventeen', 22000, 'Poster Ulang Tahun Sweet Seventeen.jpeg'),
(8, 'Poster Wedding', 20000, 'Poster Wedding.jpeg'),
(9, 'Spanduk Promosi', 20000, 'Spanduk Promosi.jpeg'),
(10, 'Spanduk Rumah Makan', 40000, 'Spanduk Rumah Makan.jpeg'),
(11, 'Spanduk Sekolah', 35000, 'Spanduk Sekolah.jpeg'),
(12, 'Spanduk Welcoming', 37000, 'Spanduk Welcoming.jpeg'),
(14, 'Thankyou Card', 30000, 'Thankyou Card.jpeg'),
(15, 'stiker', 5000, 'stiker.jpeg'),
(16, 'Spanduk PPDB', 40000, 'Spanduk PPDB.jpeg'),
(17, 'Poster Music Festival', 20000, 'Poster Music Festival.jpeg'),
(19, 'Birthday Invitation', 25000, 'Birthday Invitation.png'),
(20, 'Baby Shower Invitation', 30000, 'Baby Shower Invitation.png');

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`id`, `name`, `password`) VALUES
(0, 'dinaetikasari', '$2y$10$uOOaumEMl4de2asK0wY.x.JXTOxAyPyjfl13vRkeOrD.4E3Kgma9O'),
(0, 'shine', '$2y$10$dzW80FwT/yAFuCrnwb4rZu81oUvlsMgBnn9FcZM8/Aw2wDe1ORafa'),
(0, 'shinevardina', '$2y$10$EWUjfRVeW1iDNQViQX3NLesVgJ6V8QeOiVTzkAEzVuzfRE.lEPR6O');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `order`
--
ALTER TABLE `order`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT untuk tabel `order`
--
ALTER TABLE `order`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT untuk tabel `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
