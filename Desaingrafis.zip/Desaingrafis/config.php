<?php

$conn = mysqli_connect('localhost','root','','dbtokoabc') or die('connection failed');

?>