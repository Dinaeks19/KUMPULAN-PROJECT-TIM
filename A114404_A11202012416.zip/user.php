<?php
// Create database connection using config file
include_once("config.php");
 
// Fetch all users data from database
$result = mysqli_query($mysqli, "SELECT * FROM user ORDER BY kode_user");
?>
 
<html>
<head>    
    <title>Homepage</title>
</head>
 
<body>
<a href="adduser.php">Add New User</a><br/><br/>
<a href="index.php">kembali ke index</a><br>
 
    <table width='80%' border=1>
 
    <tr>
        <th>Kode user</th><th>Nama</th> <th>Email</th> <th>Telp</th><th>Password</th> <th>Peran</th>  <th>Update</th>
    </tr>
    <?php  
    while($user_data = mysqli_fetch_array($result)) {         
        echo "<tr>";
        echo "<td>".$user_data['kode_user']."</td>";
        echo "<td>".$user_data['nama']."</td>"; 
        echo "<td>".$user_data['email']."</td>";
        echo "<td>".$user_data['telp']."</td>";
        echo "<td>".$user_data['password']."</td>";  
        echo "<td>".$user_data['peran']."</td>";  
        echo "<td><a href='edituser.php?kode_user=$user_data[kode_user]'>Edit</a> | <a href='deleteuser.php?kode_user=$user_data[kode_user]'>Delete</a></td></tr>";        
    }
    ?>
    </table>
</body>
</html>