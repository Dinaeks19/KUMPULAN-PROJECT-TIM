<?php 
        session_start();
        include 'config.php';
     
        // menangkap data yang dikirim dari form login
        $nama = $_POST['nama'];
        $password = $_POST['password'];
     
        // menyeleksi data pada tabel admin dengan nama dan password yang sesuai
        $data = mysqli_query($mysqli,"SELECT * FROM user WHERE nama='$nama' and password='$password'");
     
        // menghitung jumlah data yang ditemukan
        $cek = mysqli_num_rows($data);
     
        if($cek > 0){
            $_SESSION['nama'] = $nama;
            $_SESSION['status'] = "login";
            header("location:index.php");
        }
        else{
            header("location:login.php?pesan=gagal");
        }
    ?>
