<html>
<head>
	<title>Add Users</title>
</head>
 
<body>
	<a href="user.php">Go to Home</a>
	<br/><br/>
 
	<form action="adduser.php" method="post" name="form1">
		<table width="25%" border="0">
			<tr> 
				<td>Name</td>
				<td><input type="text" name="nama"></td>
			</tr>
			<tr> 
				<td>Email</td>
				<td><input type="text" name="email"></td>
			</tr>
			<tr> 
				<td>telp</td>
				<td><input type="text" name="telp"></td>
			</tr>
            <tr> 
				<td>password</td>
				<td><input type="text" name="password"></td>
			</tr>
			<tr> 
				<td>peran</td>
				<td><input type="text" name="peran"></td>
			</tr>
			<tr> 
				<td></td>
				<td><input type="submit" name="Submit" value="Add"></td>
			</tr>
		</table>
	</form>
	
	<?php
 
	// Check If form submitted, insert form data into users table.
	if(isset($_POST['Submit'])) {
		$nama = $_POST['nama'];
		$email = $_POST['email'];
		$telp = $_POST['telp'];
        $password = $_POST['password'];
		$peran = $_POST['peran'];
		
		// include database connection file
		include_once("config.php");
				
		// Insert user data into table
		$result = mysqli_query($mysqli, "INSERT INTO user(nama,email,telp,password,peran) VALUES('$nama','$email','$telp','$password','$peran')");
		
		// Show message when user added
		echo "User added successfully. <a href='user.php'>View User</a>";
	}
	?>
</body>
</html>