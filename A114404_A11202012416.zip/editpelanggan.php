<?php
// include database connection file
include_once("config.php");
 
// Check if form is submitted for user update, then redirect to homepage after update
if(isset($_POST['update']))
{	
	$kode_pelanggan = $_POST['kode_pelanggan'];
	
	$nama=$_POST['nama'];
	$alamat=$_POST['alamat'];
	$telp=$_POST['telp'];
    $kode_user=$_POST['kode_user'];
		
	// update user data
	$result = mysqli_query($mysqli, "UPDATE pelanggan SET nama='$nama',alamat='$alamat',telp='$telp',kode_user='$kode_user' WHERE kode_pelanggan=$kode_pelanggan");
	
	// Redirect to homepage to display updated user in list
	header("Location: pelanggan.php");
}
?>
<?php
// Display selected user data based on id
// Getting id from url
$kode_pelanggan = $_GET['kode_pelanggan'];
 
// Fetech user data based on id
$result = mysqli_query($mysqli, "SELECT * FROM pelanggan WHERE kode_pelanggan=$kode_pelanggan");
 
while($user_data = mysqli_fetch_array($result))
{
	$nama = $user_data['nama'];
	$alamat = $user_data['alamat'];
	$telp = $user_data['telp'];
    $kode_user = $user_data['kode_user'];
}
?>
<html>
<head>	
	<title>Edit User Data</title>
</head>
 
<body>
	<a href="pelanggan.php">Home</a>
	<br/><br/>
	
	<form name="update_user" method="post" action="editpelanggan.php">
		<table border="0">
			<tr> 
				<td>Nama</td>
				<td><input type="text" name="nama" value=<?php echo $nama;?>></td>
			</tr>
			<tr> 
				<td>alamat</td>
				<td><input type="text" name="alamat" value=<?php echo $alamat;?>></td>
			</tr>
			<tr> 
				<td>telp</td>
				<td><input type="text" name="telp" value=<?php echo $telp;?>></td>
			</tr>
            <tr> 
				<td>kode_user</td>
				<td><input type="text" name="kode_user" value=<?php echo $kode_user;?>></td>
			</tr>
			
			<tr>
				<td><input type="hidden" name="kode_pelanggan" value=<?php echo $_GET['kode_pelanggan'];?>></td>
				<td><input type="submit" name="update" value="Update"></td>
			</tr>
		</table>
	</form>
</body>
</html>