<?php
// include database connection file
include_once("config.php");
 
// Check if form is submitted for user update, then redirect to homepage after update
if(isset($_POST['update']))
{	
	$kode_user = $_POST['kode_user'];
	
	$nama=$_POST['nama'];
	$email=$_POST['email'];
	$telp=$_POST['telp'];
    $password=$_POST['password'];
	$peran=$_POST['peran'];
		
	// update user data
	$result = mysqli_query($mysqli, "UPDATE user SET nama='$nama',email='$email',telp='$telp',password='$password',peran='$peran' WHERE kode_user=$kode_user");
	
	// Redirect to homepage to display updated user in list
	header("Location: user.php");
}
?>
<?php
// Display selected user data based on id
// Getting id from url
$kode_user = $_GET['kode_user'];
 
// Fetech user data based on id
$result = mysqli_query($mysqli, "SELECT * FROM user WHERE kode_user=$kode_user");
 
while($user_data = mysqli_fetch_array($result))
{
	$nama = $user_data['nama'];
	$email = $user_data['email'];
	$telp = $user_data['telp'];
    $password = $user_data['password'];
	$peran = $user_data['peran'];
}
?>
<html>
<head>	
	<title>Edit User Data</title>
</head>
 
<body>
	<a href="user.php">Home</a>
	<br/><br/>
	
	<form name="update_user" method="post" action="edituser.php">
		<table border="0">
			<tr> 
				<td>Nama</td>
				<td><input type="text" name="nama" value=<?php echo $nama;?>></td>
			</tr>
			<tr> 
				<td>Email</td>
				<td><input type="text" name="email" value=<?php echo $email;?>></td>
			</tr>
			<tr> 
				<td>telp</td>
				<td><input type="text" name="telp" value=<?php echo $telp;?>></td>
			</tr>
            <tr> 
				<td>password</td>
				<td><input type="text" name="password" value=<?php echo $password;?>></td>
			</tr>
			<tr> 
				<td>peran</td>
				<td><input type="text" name="peran" value=<?php echo $peran;?>></td>
			</tr>
			<tr>
				<td><input type="hidden" name="kode_user" value=<?php echo $_GET['kode_user'];?>></td>
				<td><input type="submit" name="update" value="Update"></td>
			</tr>
		</table>
	</form>
</body>
</html>