<?php
// include database connection file
include_once("config.php");
 
// Get id from URL to delete that user
$kode_pelanggan = $_GET['kode_pelanggan'];
 
// Delete user row from table based on given id
$result = mysqli_query($mysqli, "DELETE FROM pelanggan WHERE kode_pelanggan=$kode_pelanggan");
 
// After delete redirect to Home, so that latest user list will be displayed.
header("Location:pelanggan.php");
?>
