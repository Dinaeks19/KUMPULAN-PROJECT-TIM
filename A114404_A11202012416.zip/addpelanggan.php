<html>
<head>
	<title>Add Users</title>
</head>
 
<body>
	<a href="pelanggan.php">Go to Home</a>
	<br/><br/>
 
	<form action="addpelanggan.php" method="post" name="form1">
		<table width="25%" border="0">
			<tr> 
				<td>Name</td>
				<td><input type="text" name="nama"></td>
			</tr>
			<tr> 
				<td>alamat</td>
				<td><input type="text" name="alamat"></td>
			</tr>
			<tr> 
				<td>telp</td>
				<td><input type="text" name="telp"></td>
			</tr>
            <tr> 
				<td>kode_user</td>
				<td><input type="text" name="kode_user"></td>
			</tr>
			<tr> 
				<td></td>
				<td><input type="submit" name="Submit" value="Add"></td>
			</tr>
		</table>
	</form>
	
	<?php
 
	// Check If form submitted, insert form data into users table.
	if(isset($_POST['Submit'])) {
		$nama = $_POST['nama'];
		$alamat = $_POST['alamat'];
		$telp = $_POST['telp'];
        $kode_user = $_POST['kode_user'];
		
		// include database connection file
		include_once("config.php");
				
		// Insert user data into table
		$result = mysqli_query($mysqli, "INSERT INTO pelanggan(nama,alamat,telp,kode_user) VALUES('$nama','$alamat','$telp','$kode_user')");
		
		// Show message when user added
		echo "User added successfully. <a href='pelanggan.php'>View User</a>";
	}
	?>
</body>
</html>