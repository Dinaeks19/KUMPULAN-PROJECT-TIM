<?php
// Create database connection using config file
include_once("config.php");
 
// Fetch all users data from database
$result = mysqli_query($mysqli, "SELECT * FROM pelanggan ORDER BY kode_pelanggan");
?>
 
<html>
<head>    
    <title>Homepage</title>
</head>
 
<body>
<a href="addpelanggan.php">Add New Pelanggan</a><br/><br/>
<a href="index.php">kembali ke index</a><br>
 
    <table width='80%' border=1>
 
    <tr>
        <th>Kode Pelanggan</th><th>Nama</th> <th>alamat</th> <th>Telp</th><th>kode_user</th><th>Update</th>
    </tr>
    <?php  
    while($user_data = mysqli_fetch_array($result)) {         
        echo "<tr>";
        echo "<td>".$user_data['kode_user']."</td>";
        echo "<td>".$user_data['nama']."</td>"; 
        echo "<td>".$user_data['alamat']."</td>";
        echo "<td>".$user_data['telp']."</td>";
        echo "<td>".$user_data['kode_user']."</td>";    
        echo "<td><a href='editpelanggan.php?kode_pelanggan=$user_data[kode_pelanggan]'>Edit</a> | <a href='deletepelanggan.php?kode_pelanggan=$user_data[kode_pelanggan]'>Delete</a></td></tr>";        
    }
    ?>
    </table>
</body>
</html>