public class SuperclassDemo {
public static void main(String args[]){
    Subclass obj = new Subclass(4,7,1,8);
    obj.d=(obj.b*obj.b)-4*obj.a*obj.c;
    obj.Show();
    obj.Show("Class SubClass");
    }
}