public class SuperClass{
    //atribut
    int a;
    int b;
    int c;
    //construktor
    SuperClass(int p, int q, int r){
        this.a=p;
        this.b=q;
        this.c=r;
    }
    void Show()
    {
    System.out.println("a = " + a);
    System.out.println("b = " + b);
    System.out.println("c = " + c);
    }
    void Show(String s){
    System.out.println(s);
    }}