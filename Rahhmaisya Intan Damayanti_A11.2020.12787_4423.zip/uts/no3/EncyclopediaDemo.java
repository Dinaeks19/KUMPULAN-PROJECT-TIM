public class EncyclopediaDemo{
	public static void main(String[] args){
		Encyclopedia pp = new Encyclopedia("Encyclopedia","Intan",978897,451);
		pp.print();
	}
}