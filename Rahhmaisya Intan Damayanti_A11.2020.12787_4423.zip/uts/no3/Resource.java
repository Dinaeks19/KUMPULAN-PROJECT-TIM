public class Resource{
	private String title;
	
	public String gettitle(){
		return title;
	}
		public void settitle(String title){
		this.title = title;
	}
	
}