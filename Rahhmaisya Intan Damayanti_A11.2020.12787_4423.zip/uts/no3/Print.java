public class Print extends Resource{
	private String author;
	private String publisher;
	private String category;
	private int isbn;
	
	public String getauthor(){
		return author;
	}
		public void setauthor(String author){
		this.author = author;
	}
		public String getpublisher(){
		return publisher;
	}
		public void setpublisher(String publisher){
		this.publisher = publisher;
	}
		public String getcategory(){
		return category;
	}
		public void setcategory(String category){
		this.category = category;
	}
		public int getisbn(){
		return isbn;
	}
		public void setisbn(int isbn){
		this.isbn = isbn;
	}
	public String toString(){
		return "author = "+getauthor()+" | Edition = "+getpublisher()+" | ";
	
	
	}
}