public class Encyclopedia extends Print{
	private int Volume;
	private int Edition;
	public Encyclopedia(String title,String author, int isbn,int Volume){
		setVolume(Volume);
		setisbn(isbn);
		settitle(title);
		setauthor(author);
	}
		public int getVolume(){ 
		return Volume;
	}
		public void setVolume(int Volume){ 
		this.Volume = Volume;
	}
	
		public int getEdition(){ 
		return Edition;
	}
		public void setEdition(int Edition){ 
		this.Edition = Edition;
	}

	public String toString(){
		return super.toString()+"Title = "+gettitle()+" | luas = "+getEdition();
	}
	void print(){
        System.out.println("====================================");
        System.out.println("Title   : "+gettitle());
        System.out.println("Author  : " + getauthor());
       
        System.out.println("ISBN    : " + getisbn());
        System.out.println("Volume  : "+ getVolume());
}
}
